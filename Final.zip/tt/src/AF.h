#ifndef AF_H_INCLUDED
#define AF_H_INCLUDED

#include <gtk/gtk.h>
typedef struct
{
  int jour;
  int mois;
  int annee;
}date;
typedef struct
{
  char spec[20];
  int niv;
}classe;
typedef struct
{
  char nom[30];
  char prenom[30];
  date naissance;
  classe niveau;
  int chambre;
  int CIN;
  int tel;
}Etudiant;

void ajouter(Etudiant E,char txt[]);
void rechercher(int cn/*char txt[]*/);
void modifier(int choix,Etudiant E,char ch[],char id[]);
void supprimer(char ch[],char id[]);
void afficher(GtkWidget *liste,char txt[]);
int niveau(int calcul[],char txt[]);

#endif // AF_H_INCLUDED
