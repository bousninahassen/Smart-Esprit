#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "AF.h"

//enum
enum
{
	NOM,
	PRENOM,
	DATE,
	NIVEAU,
	CHAMBRE,
	CIN,
	TEL,
	COLUMNS,
};


//ajouter
void ajouter(Etudiant E,char txt[])
{
    FILE *f;
    f=fopen(txt,"a");
    if(f!=NULL)
    {
        fprintf(f,"%s %s %d %d %d %d %s %d %d %d\n",E.nom,E.prenom,E.naissance.jour,E.naissance.mois,E.naissance.annee,E.niveau.niv,E.niveau.spec,E.chambre,E.CIN,E.tel);
        fclose(f);
    }
}


//chercher
void rechercher(int cn/*char txt[]*/)
{
    FILE *f,*l;
    char ch1[30],nai[20],cat[15];
    char ch2[30],ech[20],gch[20],hch[20];
    int a,b,c,d,e,g,h;
    char ch3[20];
    f=fopen("etudiant.txt","r");
    l=fopen("temp.txt","a");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h)!= EOF)
        {
            if(cn==g)
            {
		sprintf(cat,"%d",a);
		strcpy(nai,strcat(cat,"/"));
		sprintf(cat,"%d",b);
		strcat(nai,strcat(cat,"/"));
		sprintf(cat,"%d",c);
		strcat(nai,cat);
		sprintf(cat,"%d",d);
		strcat(cat,ch3);
		sprintf(ech,"%d",e);
		sprintf(gch,"%d",g);
		sprintf(hch,"%d",h);
               fprintf(l,"%s %s %s %s %s %s %s\n",ch1,ch2,nai,cat,ech,gch,hch);
            }
        }
    }
    fclose(f);
    fclose(l);
}

//modifier
void modifier(int choix,Etudiant E,char sup[],char id[])
{
    FILE *f,*l;
    char ch1[30];
    char ch2[30];
    int a,b,c,d,e,g,h;
    char ch3[20];
    f=fopen("etudiant.txt","r");
    l=fopen("tmp.txt","a+");
    if(f!=NULL)
    {

        while(fscanf(f,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h)!= EOF)
        {
            if ((strcmp(sup,ch1)==0) && (strcmp(id,ch2)==0))
            {	
                  strcpy(ch1,E.nom);fscanf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h);
		  strcpy(ch2,E.prenom);fscanf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h);
		  d=choix;fscanf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h);
		  e=E.chambre;fscanf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h);
  		  h=E.tel;fscanf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h);
                  fprintf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,a,b,c,d,ch3,e,g,h);
            }
            else
            {
                fprintf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,a,b,c,d,ch3,e,g,h);
            }
	     
        }
    }
    fclose(f);
    fclose(l);
    remove("etudiant.txt");
    rename("tmp.txt","etudiant.txt");
}


//supprimer
void supprimer(char ch[],char id[])
{
    FILE *f,*l;
    char ch1[30];
    char ch2[30];
    int a,b,c,d,e,g,h;
    char ch3[20],gstr[10];
    f=fopen("etudiant.txt","r");
    l=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h)!= EOF)
        {
            if ((strcmp(ch,ch1)!=0) && (strcmp(id,ch2)!=0))
            {
                fprintf(l,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,a,b,c,d,ch3,e,g,h);
            }
        }
    }
    fclose(f);
    fclose(l);
    remove("etudiant.txt");
    rename("tmp.txt","etudiant.txt");
}

//afficher
void afficher(GtkWidget *liste,char txt[])
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    char ch1[30];
    char ch2[30],ech[20],gch[20],hch[20];
    int a,b,c,d,e,g,h;
    char ch3[20],nai[100],cat[100];
    store=NULL;

    FILE *f;

    store=gtk_tree_view_get_model(liste);
    if(store==NULL)
    {
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Prenom",renderer,"text",PRENOM,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Date de naissance",renderer,"text",DATE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("Niveau",renderer,"text",NIVEAU,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    column = gtk_tree_view_column_new_with_attributes("Chambre",renderer,"text",CHAMBRE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("N°cin",renderer,"text",CIN,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("N°tel",renderer,"text",TEL,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
    renderer = gtk_cell_renderer_text_new();

    store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

    f=fopen(txt,"r");

    if(f==NULL)
    {return;}
    else
    {
	if(strcmp(txt,"etudiant.txt")==0)
	{
     while(fscanf(f,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h)!= EOF)
        {
	    sprintf(cat,"%d",a);
	strcpy(nai,strcat(cat,"/"));
	sprintf(cat,"%d",b);
	strcat(nai,strcat(cat,"/"));
	sprintf(cat,"%d",c);
	strcat(nai,cat);
	sprintf(cat,"%d",d);
	strcat(cat,ch3);
	    gtk_list_store_append(store,&iter);
	    gtk_list_store_set(store,&iter,NOM,ch1,PRENOM,ch2,DATE,nai,NIVEAU,cat,CHAMBRE,e,CIN,g,TEL,h,-1);
        }
	}
	else 
	{
while(fscanf(f,"%s %s %s %s %s %s %s\n",ch1,ch2,nai,cat,ech,gch,hch)!= EOF)
        {
	 gtk_list_store_append(store,&iter);
	    gtk_list_store_set(store,&iter,NOM,ch1,PRENOM,ch2,DATE,nai,NIVEAU,cat,CHAMBRE,e,CIN,g,TEL,h,-1);	
}
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref (store);
    }
    }   
}


//calcul niveau
int niveau(int calcul[],char txt[])
{


 FILE *f;
    char ch1[30];
    char ch2[30];
    int a,b,c,d,e,g,h,s1=0,s2=0,s3=0,s4=0,s5=0,s=0;
    char ch3[20];
    f=fopen(txt,"r");
  if(f!=NULL)
  {
        
          
		while(fscanf(f,"%s %s %d %d %d %d %s %d %d %d \n",ch1,ch2,&a,&b,&c,&d,ch3,&e,&g,&h)!= EOF)
			
        	{ 		if((calcul[0]==1) && (d==1))

                                 {
                                  s1++;

                                 }

  				if((calcul[1]==1) && (d==2))
                                {
                                 s2++;

                                }

 				if((calcul[2]==1) && (d==3))
                                {
              			 s3++;

            			}

 				if((calcul[3]==1) && (d==4))
            			{
              			s4++;

            			}

 				if((calcul[4]==1) && (d==5))
            			{
              			s5++;

            			}
       
    		}
s=s1+s2+s3+s4+s5;
 }
    fclose(f);
return s;
	}




