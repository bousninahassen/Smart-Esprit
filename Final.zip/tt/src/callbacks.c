#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include  "AF.h"

//var global
int choix;
Etudiant E,ET;
char sup[100],id[10],dtnai[400],nv[200],nat[40],so[200];
int chmb,num,calcul[5]={0,0,0,0,0};

//button_ajouter
void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
   
//Déclaration
GtkWidget *nom,*prenom,*chambre,*cin,*tel,*jour,*mois,*annee,*niveau,*spc,*invalid;
char x[10];


nom = lookup_widget(button, "entry_nom") ;
strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

prenom = lookup_widget(button, "entry_prenom") ;
strcpy(E.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

jour= lookup_widget(button, "spinbutton_jour");
E.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));


mois= lookup_widget(button, "spinbutton_mois");
E.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));


annee= lookup_widget(button, "spinbutton_annee");
E.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));



niveau= lookup_widget(button, "combobox_niveau");
strcpy(x,gtk_combo_box_get_active_text(GTK_COMBO_BOX(niveau)));
E.niveau.niv=atoi(x);

spc= lookup_widget(button, "combobox_spc");
strcpy(E.niveau.spec,gtk_combo_box_get_active_text(GTK_COMBO_BOX(spc)));



chambre= lookup_widget(button, "entry_chambre");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(chambre)));
E.chambre=atoi(x);

tel= lookup_widget(button, "entry_tel");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(tel)));
E.tel=atoi(x);


cin= lookup_widget(button, "entry_cin");
strcpy(x,gtk_entry_get_text(GTK_ENTRY(cin)));
E.CIN=atoi(x);
invalid = lookup_widget(button, "label_invalid") ; 
if ((strlen(x)!=8) && (strlen(x)!=7))
{
gtk_label_set_text(GTK_LABEL(invalid),"invalide");}
else {
gtk_label_set_text(GTK_LABEL(invalid),"valide");
ajouter(E,"etudiant.txt");
}

}

//button_ajouter_tab
void
on_button_ajouter_tab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1,*principale;
window1 = create_window1 ();
gtk_widget_show (window1);
principale=lookup_widget(button,"principale");
gtk_widget_destroy(principale);

}

//modif_tab
void
on_button_modifier_tab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifier,*principale;
principale=lookup_widget(button,"principale");
gtk_widget_destroy(principale);
modifier = create_modifier ();
gtk_widget_show (modifier);

}

//button_return_ajouter
void
on_button_return_ajouter_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *principale,*window1,*treeview;
principale = create_principale ();
gtk_widget_show (principale);
window1=lookup_widget(button,"window1");
gtk_widget_destroy(window1);
}



//button_return_modifier
void
on_button_return_modifier_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *principale,*modifier;
principale = create_principale ();
gtk_widget_show (principale);
modifier=lookup_widget(button,"modifier");
gtk_widget_destroy(modifier);
}

//button_modifier
void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*chambre,*tel;
//nom
nom = lookup_widget(button, "entry_modif_nom") ;
gtk_entry_set_text(GTK_ENTRY(nom),sup);
//prenom
prenom = lookup_widget(button, "entry_modif_prenom") ;
gtk_entry_set_text(GTK_ENTRY(prenom),id);
//appel modifier
//modifier(choix,E,sup,id);
}

//button_chercher_tab
void
on_button_chercher_tab_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *carte,*treeview;
int cn;
char c[10]; 
//appel rechercher
remove("temp.txt");
carte= lookup_widget(button, "entry_chercher_tab");
strcpy(c,gtk_entry_get_text(GTK_ENTRY(carte)));
cn=atoi(c);
rechercher(cn);
//appel afficher
treeview=lookup_widget(button,"treeview");
afficher(treeview,"temp.txt");

}

//button_affich_tab
void
on_button_affich_tab_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview,*principale;
principale=lookup_widget(button,"principale");
treeview=lookup_widget(button,"treeview");
principale = create_principale ();
gtk_widget_show (principale);
gtk_widget_destroy(principale);
afficher(treeview,"etudiant.txt");
}

//treeview_row
void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ch1;
gchar* ch2;
gchar* nai;
gchar* cat;
gchar* e;
gchar* g;
gchar* h;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path));
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&ch1,1,&ch2,2,&nai,3,&cat,4,&e,5,&g,6,&h,-1);
strcpy(sup,ch1);
strcpy(id,ch2);
afficher(treeview,"etudiant.txt");
}
}

//button_supprim_tab
void
on_button_supprim_tab_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer(sup,id);
GtkWidget *principale;
principale=lookup_widget(button,"principale");
gtk_widget_destroy(principale);
principale = create_principale ();
gtk_widget_show (principale);

}


//radiobutton_modif1
void
on_radiobutton_modif1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=1;
}

//radiobutton_modif2
void
on_radiobutton_modif2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=2;
}

//radiobutton_modif3
void
on_radiobutton_modif3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=3;
}

//radiobutton_modif4
void
on_radiobutton_modif4_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=4;
}

//radiobutton_modif5
void
on_radiobutton_modif5_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
choix=5;
}

//button_modif_enregistrer
void
on_button_modif_enregistrer_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*chambre,*tel;
//nom
nom = lookup_widget(button, "entry_modif_nom") ;
strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
//prenom
prenom = lookup_widget(button, "entry_modif_prenom") ;
strcpy(E.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
//chambre
char n1[10];
chambre = lookup_widget(button, "entry_modif_chambre") ;
strcpy(n1,gtk_entry_get_text(GTK_ENTRY(chambre)));
E.chambre=atoi(n1);
//tel
char n2[20];
tel = lookup_widget(button, "entry_modif_tel") ;
strcpy(n2,gtk_entry_get_text(GTK_ENTRY(tel)));
E.tel=atoi(n2);
modifier(choix,E,sup,id);
}

//button_calcul_tab
void
on_button_calcul_tab_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowc,*principale;
windowc = create_calcul ();
gtk_widget_show (windowc);
principale=lookup_widget(button,"principale");
gtk_widget_destroy(principale);
}

//checkbutton_calcul_1
void
on_checkbutton_calcul_1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(togglebutton))
{calcul[0]=1;
}
else
{calcul[0]=0;}
}

//checkbutton_calcul_2
void
on_checkbutton_calcul_2_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[1]=1;
}
else
{calcul[1]=0;}
}

//checkbutton_calcul_3
void
on_checkbutton_calcul_3_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[2]=1;
}
else
{calcul[2]=0;}
}

//checkbutton_calcul_4
void
on_checkbutton_calcul_4_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[3]=1;}
else
{calcul[3]=0;}
}

//checkbutton_calcul_5
void
on_checkbutton_calcul_5_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{calcul[4]=1;}
else
{calcul[4]=0;}
}

//button_calcul_sum
void
on_button_calcul_sum_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *somme;
int sum;
somme = lookup_widget(button, "label_calcul_s") ;
sum=niveau(calcul,"etudiant.txt");
sprintf(so,"%d",sum);
gtk_label_set_text(GTK_LABEL(somme),so);
}

