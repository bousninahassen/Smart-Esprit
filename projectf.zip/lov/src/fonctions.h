#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}date;

typedef struct
{
    char p_n[20];
    char role[20];
    char n_u[20];
    char mdp[20];
    char confirmer[20];
    date date_mise_fct;
    char id[20];
    char sexe[20];
    char etat[20];
}user;

typedef struct
{
int jour;
int mois ;
int annee;
}date5;


typedef struct
{
char id[50];
char type[50];
char nom[50];
date5 date_exp;
date5 date_ajout;
float kg;
}nourriture;

void ajouter(user n);
void afficher(GtkWidget *liste);
void supprimer(char refsp[]);
void modifier(user n);
void chercher(GtkWidget *liste, char ref[]);
int verif(char ref[]);






