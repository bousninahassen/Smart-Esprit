#include <gtk/gtk.h>


void
on_buttonQuit_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonConnect_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonges_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_gha_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_return_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajuster_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_anuller_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourges_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supuser_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retges_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_brech_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_rtrech_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_mc_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button300_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_allc_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_addc_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affc_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterc_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajm_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifrec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkid2clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview5rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af3_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajrec_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajoutera_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifiera_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_affichera_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_meilleur_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_moda_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affa_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_aja_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_rechercher_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_rupture_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_supp_oui_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_affich_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_supp_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_ajout_prod_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_annuler_ajout_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_affich_ajout_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_fruit_a_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_legume_a_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_viande_a_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_liquides_a_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ingredients_a_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_annuler_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_affich_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rech_valider_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_hh_rupture_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_rupture_clicked              (GtkButton       *button,
                                        gpointer         user_data);
