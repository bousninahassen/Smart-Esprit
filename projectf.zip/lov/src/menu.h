#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct date3
{
    int j;
    int m;
    int a;
}date3;

typedef struct menu
{
    char id[20];
    int type;
    char nom[20];
    float dechet;
    date3 d;
}menu;

void ajouter2(menu u, char *fname);
void supprimer2(menu u, char *fname);
void modifier2(menu u, char *fname);
void afficher2(GtkWidget *liste, char *fname);
char* meilleur_menu(char *fname);
int year_week(const struct tm *tmptr, int *year, int *week);

