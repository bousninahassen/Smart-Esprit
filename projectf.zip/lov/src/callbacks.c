#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"
#include "capteur.h"
#include "reclam.h"
#include "menu.h"




int x_equ=1;
int y_equ=0;
int a_equ=1;
int b_equ=0;




void
on_buttonQuit_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *login;

login=lookup_widget(button,"login");
gtk_widget_destroy(login);
}




void
on_buttonConnect_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entry1, *entry2, *pInfo, *Menu_admin, *login;



char id[20], mdp[20];
int a=0;
FILE *f;
entry1=lookup_widget(button,"entry1");
entry2=lookup_widget(button,"entry2");
f=fopen("admin.txt","a+");
while(fscanf(f,"%s %s\n",id,mdp)!=EOF){
if(strcmp(id,gtk_entry_get_text(entry1))==0&&strcmp(mdp,gtk_entry_get_text(entry2))==0)
a++;
}
if(a!=0){
login=lookup_widget(button,"login");
gtk_widget_destroy(login);
Menu_admin=lookup_widget(button,"Menu_admin");
Menu_admin=create_Menu_admin();
gtk_widget_show(Menu_admin);
}
if(a==0){
    pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Veuillez vérifier vos données");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }

   


        }
fclose(f);

}



void
on_buttonges_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *gestion;
Menu_admin=lookup_widget(button,"Menu_admin");
gtk_widget_destroy(Menu_admin);
gestion=lookup_widget(button,"gestion");
gestion=create_gestion();
gtk_widget_show(gestion);
}



void
on_retourlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *login;
Menu_admin=lookup_widget(button,"Menu_admin");
gtk_widget_destroy(Menu_admin);
login=lookup_widget(button,"login");
login=create_login();
gtk_widget_show(login);
}
void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *dashborad;
Menu_admin=lookup_widget(button,"Menu_admin");
gtk_widget_destroy(Menu_admin);
dashborad=lookup_widget(button,"dashborad");
dashborad=create_dashborad();
gtk_widget_show(dashborad);
}
void
on_gha_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *gha;
Menu_admin=lookup_widget(button,"Menu_admin");
gtk_widget_destroy(Menu_admin);
gha=lookup_widget(button,"gha");
gha=create_gha();
gtk_widget_show(gha);
}
void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *amal;
Menu_admin=lookup_widget(button,"Menu_admin");
gtk_widget_destroy(Menu_admin);
amal=lookup_widget(button,"amal");
amal=create_amal();
gtk_widget_show(amal);
}

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
    gchar* id;
    gchar* p_n;
    gchar* role;
    gchar* n_u;
    gchar* mdp;
    gchar* etat;
    gchar* confirmer;
    gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
    gchar* sexe;
    GtkWidget *gestion,*treeview1;

    user n;
        FILE *f=NULL;
        
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter ,path))
    {
        
        gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &p_n, 2, &role , 3, &n_u, 4, &mdp, 5, &etat , 6, &confirmer , 7, &sexe , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
        strcpy(n.id,id);
        strcpy(n.p_n,p_n);
        strcpy(n.role,role);
                strcpy(n.n_u,n_u);
        strcpy(n.mdp,mdp);
        strcpy(n.etat,etat);
                strcpy(n.confirmer,confirmer);
                strcpy(n.sexe,sexe);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
        supprimer(n.id);
        gestion=create_gestion();
        gtk_widget_show(gestion);
        treeview1=lookup_widget(gestion,"treeview1");
        afficher(treeview1);
        gtk_widget_show(treeview1);
        gestion=lookup_widget(treeview,"gestion");
        gtk_widget_destroy(gestion);

                
                
                
                
}
}


void
on_button_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *aj, *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
aj=lookup_widget(button,"aj");
aj=create_aj();
gtk_widget_show(aj);

}


void
on_button_af_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;

treeview1=lookup_widget(button,"treeview1");

afficher(treeview1);
}



void
on_button_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *ajmod, *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
ajmod=lookup_widget(button,"ajmod");
ajmod=create_ajmod();
gtk_widget_show(ajmod);


}


void
on_button_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *supp, *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
supp=lookup_widget(button,"supp");
supp=create_supp();
gtk_widget_show(supp);
}


void
on_button_return_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *Menu_admin, *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
Menu_admin=lookup_widget(button,"Menu_admin");
Menu_admin=create_supp();
gtk_widget_show(Menu_admin);
}


void
on_button_rech_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget   *rech, *gestion;
gestion=lookup_widget(button,"gestion");
gtk_widget_destroy(gestion);
rech=lookup_widget(button,"rech");
rech=create_rech();
gtk_widget_show(rech);
}


void
on_anuller_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget   *aj, *gestion;
aj=lookup_widget(button,"aj");
gtk_widget_destroy(aj);
gestion=lookup_widget(button,"gestion");
gestion=create_gestion();
gtk_widget_show(gestion);

}


void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
    if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
a_equ=2;
    }

}


void
on_ajuster_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
user n;

  GtkWidget *gestion , *aj ;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *role,*etat;
   


aj=lookup_widget(button,"aj");
input1=lookup_widget(button,"id");
input2=lookup_widget(button,"pn");
input3=lookup_widget(button,"user");
input4=lookup_widget(button,"pass");
role=lookup_widget(button,"role");
etat=lookup_widget(button,"etat");
jour=lookup_widget(button,"bjour");
mois=lookup_widget(button,"bmois");
annee=lookup_widget(button,"banne");

strcpy(n.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.p_n,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.n_u,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.mdp,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(x_equ==1)
{strcpy(n.sexe,"homme");}
else
if(x_equ==2)
{strcpy(n.sexe,"femme");}

if(y_equ==1)
{strcpy(n.confirmer,"oui");}
else
if(y_equ==0)
{strcpy(n.confirmer,"non");}

ajouter(n);
x_equ=1;
y_equ=0;


    gtk_widget_destroy(aj);
    gestion=create_gestion();
    gtk_widget_show(gestion);
}


void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
a_equ=1;
    }
}



void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
    {
y_equ=1;
    }
}


void
on_modif_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
user n;

  GtkWidget *gestion , *ajmod ;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *role,*etat;
   


ajmod=lookup_widget(button,"ajmod");
input1=lookup_widget(button,"entry3");
input2=lookup_widget(button,"entry4");
input3=lookup_widget(button,"entry5");
input4=lookup_widget(button,"entry6");
role=lookup_widget(button,"combobox1");
etat=lookup_widget(button,"combobox2");
jour=lookup_widget(button,"spinbutton1");
mois=lookup_widget(button,"spinbutton2");
annee=lookup_widget(button,"spinbutton3");

strcpy(n.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.p_n,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.n_u,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.mdp,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(x_equ==1)
{strcpy(n.sexe,"homme");}
else
if(x_equ==2)
{strcpy(n.sexe,"femme");}

if(y_equ==1)
{strcpy(n.confirmer,"oui");}
else
if(y_equ==0)
{strcpy(n.confirmer,"non");}

modifier(n);
a_equ=1;
b_equ=0;



    gtk_widget_destroy(ajmod);
    gestion=create_gestion();
    gtk_widget_show(gestion);
}



void
on_retourges_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget   *ajmod, *gestion;
ajmod=lookup_widget(button,"ajmod");
gtk_widget_destroy(ajmod);
gestion=lookup_widget(button,"gestion");
gestion=create_gestion();
gtk_widget_show(gestion);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a_equ=1;
}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a_equ=2;
}
}



void
on_button_supuser_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supp , *gestion;
   GtkWidget *ref;
   GtkWidget *output;
   char refsp[20];
   char msg[20];
   int t;
ref=lookup_widget(button,"idsup");
output=lookup_widget(button,"label435");
strcpy(refsp,gtk_entry_get_text(GTK_ENTRY(ref)));
t=verif(refsp);
if(t!=1)
{
   strcpy(msg,"Donnée invalide");
    gtk_label_set_text(GTK_LABEL(output),msg);
}
else
{
    supprimer(refsp);
    strcpy(msg,"Suppression Réussi");
    gtk_label_set_text(GTK_LABEL(output),msg);
    supp=lookup_widget(button,"supp");
    gtk_widget_destroy(supp);
    gestion=create_gestion();
    gtk_widget_show(gestion);
}
   
}


void
on_button_retges_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget   *supp, *gestion;
supp=lookup_widget(button,"supp");
gtk_widget_destroy(supp);
gestion=lookup_widget(button,"gestion");
gestion=create_gestion();
gtk_widget_show(gestion);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    gchar* id;
    gchar* p_n;
    gchar* role;
    gchar* n_u;
    gchar* mdp;
    gchar* etat;
    gchar* confirmer;
    gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
    gchar* sexe;

    user n;
        FILE *f=NULL;
        
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter ,path))
    {
        
        gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &p_n, 2, &role , 3, &n_u, 4, &mdp, 5, &etat , 6, &confirmer , 7, &sexe , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
        strcpy(n.id,id);
        strcpy(n.p_n,p_n);
        strcpy(n.role,role);
                strcpy(n.n_u,n_u);
        strcpy(n.mdp,mdp);
        strcpy(n.etat,etat);
                strcpy(n.confirmer,confirmer);
                strcpy(n.sexe,sexe);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;


         afficher(treeview);
          }
}


void
on_rtrech_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkWidget *rech, *gestion;
    rech=lookup_widget(button,"rech");
    gtk_widget_destroy(rech);
    gestion=create_gestion();
    gtk_widget_show(gestion);
}



void
on_brech_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *rech , *ref, *treeview2;
  
   char refrech[20];
   

ref=lookup_widget(button,"entry7");


strcpy(refrech,gtk_entry_get_text(GTK_ENTRY(ref)));
rech=create_rech();
gtk_widget_show(rech);
treeview2=lookup_widget(rech,"treeview2");
gtk_widget_show(treeview2);

chercher(treeview2, refrech);
rech=lookup_widget(button,"rech");
gtk_widget_destroy(rech);
}





void
on_addc_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajj, *dashborad;
dashborad=lookup_widget(button,"dashborad");
ajj=lookup_widget(button,"ajj");
ajj=create_ajj();
gtk_widget_show(ajj);

}


void
on_mc_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod, *dashboard;
dashboard=lookup_widget(button,"dashboard");
mod=lookup_widget(button,"mod");
mod=create_mod();
gtk_widget_show(mod);
}




void
on_button300_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af;
af=lookup_widget(button,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview");
afficher1(treeview,"capteurs.txt");
}


void
on_allc_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *def, *treeview;
def=lookup_widget(button,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_def");
alarme_panne(treeview,"mesures.txt");
}




void
on_check_id_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo;
capteur p;
int a=0;
char id[50];
FILE *f;
mod1=lookup_widget(button,"entry8");
mod2=lookup_widget(button,"combobox3");
mod3=lookup_widget(button,"entry9");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("capteurs.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %d %d %d\n",p.id,&(p.type),p.marque,&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
    {
        if(strcmp(p.id,id)==0){
            a=1;
            break;
                 }
    }
fclose(f);
}
if(a==1){
gtk_combo_box_set_active(GTK_COMBO_BOX(mod2),p.type);
gtk_entry_set_text(GTK_ENTRY(mod3),p.marque);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Capteur introuvable");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}

}


void
on_button_mod_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo;
capteur u;
mod1=lookup_widget(button,"entry8");
mod2=lookup_widget(button,"combobox3");
mod3=lookup_widget(button,"entry9");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(mod1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(mod2));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(mod3)));
modifier1(u,"capteurs.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Capteur modifié avec succès");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}


void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    gchar *id;
    capteur u;
    GtkWidget *pInfo;
    GtkTreeModel *model=gtk_tree_view_get_model(treeview);
    if(gtk_tree_model_get_iter(model,&iter,path)){
    gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
    strcpy(u.id,id);
    pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce capteur?");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_YES:
    gtk_widget_destroy(pInfo);
    supprimer1(u,"capteurs.txt");
    afficher1(treeview,"capteurs.txt");
    break;
    case GTK_RESPONSE_NO:
    gtk_widget_destroy(pInfo);
    break;
}   
}
}


void
on_affc_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af;
af=lookup_widget(button,"af");
gtk_widget_destroy(af);
af=lookup_widget(button,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview3");
afficher1(treeview,"capteurs.txt");
}


void
on_ajouterc_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3;
GtkCalendar *ajc;
capteur u;
guint day, month, year;
aj1=lookup_widget(button,"entry11");
aj2=lookup_widget(button,"combobox4");
aj3=lookup_widget(button,"entry10");
ajc=lookup_widget(button,"da");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
ajouter1(u,"capteurs.txt");
}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj_mesure, *def;
def=lookup_widget(button,"def");
aj_mesure=lookup_widget(button,"aj_mesure");
aj_mesure=create_aj_mesure();
gtk_widget_show(aj_mesure);
}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *def;
def=lookup_widget(button,"def");
gtk_widget_destroy(def);
def=lookup_widget(button,"def");
def=create_def();
gtk_widget_show(def);
treeview=lookup_widget(def,"treeview_4");
alarme_panne(treeview,"mesures.txt");
}


void
on_button_ajm_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *h, *m;
GtkCalendar *ajc;
mesure u;
guint day, month, year;
aj1=lookup_widget(button,"ajm1");
aj2=lookup_widget(button,"ajm2");
aj3=lookup_widget(button,"ajm3");
aj4=lookup_widget(button,"ajm4");
aj5=lookup_widget(button,"ajm5");
ajc=lookup_widget(button,"ajmc");
h=lookup_widget(button,"h");
m=lookup_widget(button,"m");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(aj2));
strcpy(u.marque,gtk_entry_get_text(GTK_ENTRY(aj3)));
strcpy(u.etage,gtk_entry_get_text(GTK_ENTRY(aj4)));
u.valeur=atof(gtk_entry_get_text(GTK_ENTRY(aj5)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
u.h=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(h));
u.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
ajouter_mesure(u,"mesures.txt");
}



void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj, *gha;
gha=lookup_widget(button,"gha");
aj=lookup_widget(button,"aj");
aj=create_aj();
gtk_widget_show(aj);

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod2, *gha;
gha=lookup_widget(button,"gha");
mod2=lookup_widget(button,"mod2");
mod2=create_mod2();
gtk_widget_show(mod2);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af2;
af2=lookup_widget(button,"af2");
af2=create_af2();
gtk_widget_show(af2);
treeview=lookup_widget(af2,"treeview5");
afficher3(treeview,"reclamations.txt");
}


void
on_modifrec_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod21, *mod22, *mod23, *pInfo, *mod24, *mod25, *r1, *r2, *r3, *r4, *r5, *r6;
reclam u;
mod21=lookup_widget(button,"entry12");
mod22=lookup_widget(button,"entry13");
mod23=lookup_widget(button,"entry14");
mod24=lookup_widget(button,"entry15");
mod25=lookup_widget(button,"entry16");
r1=lookup_widget(button,"radiobutton3");
r2=lookup_widget(button,"radiobutton4");
r3=lookup_widget(button,"radiobutton5");
r4=lookup_widget(button,"radiobutton6");
r5=lookup_widget(button,"radiobutton7");
r6=lookup_widget(button,"radiobutton8");
u.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod21)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(mod22)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(mod23)));
strcpy(u.classe,gtk_entry_get_text(GTK_ENTRY(mod24)));
u.service=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(r1))?0:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(r2))?1:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(r3))?2:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(r4))?3:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(r5))?4:5;
strcpy(u.desc,gtk_entry_get_text(GTK_ENTRY(mod25)));
modifier3(u,"reclamations.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Réclamation modifiée avec succès");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }

}



void
on_checkid2clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod21, *mod22, *mod23, *pInfo, *mod24, *mod25, *r1, *r2, *r3, *r4, *r5, *r6;
reclam p;
char str[100];
char* desc = (char*) malloc(500);
strcpy(desc,"");
int a=0, id;
FILE *f, *file;
mod21=lookup_widget(button,"entry12");
mod22=lookup_widget(button,"entry13");
mod23=lookup_widget(button,"entry14");
mod24=lookup_widget(button,"entry15");
mod25=lookup_widget(button,"entry16");
r1=lookup_widget(button,"radiobutton3");
r2=lookup_widget(button,"radiobutton4");
r3=lookup_widget(button,"radiobutton5");
r4=lookup_widget(button,"radiobutton6");
r5=lookup_widget(button,"radiobutton7");
r6=lookup_widget(button,"radiobutton8");
id = atoi(gtk_entry_get_text(GTK_ENTRY(mod21)));
f = fopen("reclamations.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %s %d\n",&(p.id),p.prenom,p.nom,p.classe,&(p.service))!=EOF)
    {
        if(p.id==id){
            a=1;
            break;
                 }
    }
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod22),p.prenom);
gtk_entry_set_text(GTK_ENTRY(mod23),p.nom);
gtk_entry_set_text(GTK_ENTRY(mod24),p.classe);
p.service==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r1),TRUE):p.service==1?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r2),TRUE):p.service==2?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r3),TRUE):p.service==3?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r4),TRUE):p.service==4?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r5),TRUE):gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r6),TRUE);
sprintf(str,"%d.txt",id);
file = fopen(str,"a+");
if(file){
while(!feof(file))
fgets(desc,500,file);
fclose(file);
}
memmove(&desc[strlen(desc)-1],&desc[strlen(desc)],strlen(desc) - (strlen(desc)-1));
gtk_entry_set_text(GTK_ENTRY(mod25),desc);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Réclamation introuvable");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}

}
void
on_treeview5rec_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    gint id;
    reclam u;
    char str[100];
    GtkWidget *pInfo;
    GtkTreeModel *model=gtk_tree_view_get_model(treeview);
    if(gtk_tree_model_get_iter(model,&iter,path)){
    gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
    u.id=id;
    pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer cette réclamation?");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_YES:
    gtk_widget_destroy(pInfo);
    supprimer3(u,"reclamations.txt");
    sprintf(str,"%d.txt",u.id);
    remove(str);
    break;
    case GTK_RESPONSE_NO:
    gtk_widget_destroy(pInfo);
    break;
}   
}
}


void
on_button_af3_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af2;
af2=lookup_widget(button,"af2");
gtk_widget_destroy(af2);
af2=lookup_widget(button,"af2");
af2=create_af2();
gtk_widget_show(af2);
treeview=lookup_widget(af2,"treeview5");
afficher3(treeview,"reclamations.txt");
}


void
on_button_ajrec_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6;
reclam u;
aj1=lookup_widget(button,"spinbutton4");
aj2=lookup_widget(button,"entry18");
aj3=lookup_widget(button,"entry17");
aj4=lookup_widget(button,"entry19");
aj5=lookup_widget(button,"combobox5");
aj6=lookup_widget(button,"entry20");
u.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aj1));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(aj2)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(aj3)));
strcpy(u.classe,gtk_entry_get_text(GTK_ENTRY(aj4)));
u.service=gtk_combo_box_get_active(GTK_COMBO_BOX(aj5));
strcpy(u.desc,gtk_entry_get_text(GTK_ENTRY(aj6)));
ajouter3(u,"reclamations.txt");
}




void
on_ajoutera_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aja, *amal;
amal=lookup_widget(button,"amal");
aja=lookup_widget(button,"aja");
aja=create_aja();
gtk_widget_show(aja);
}


void
on_modifiera_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo, *mod4;
menu u;
mod1=lookup_widget(button,"entry22");
mod2=lookup_widget(button,"entry21");
mod3=lookup_widget(button,"entry23");
mod4=lookup_widget(button,"combobox6");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(mod1)));
u.type=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(mod2)));
u.dechet = atof(gtk_entry_get_text(GTK_ENTRY(mod3)));
modifier2(u,"menu.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Menu modifié avec succès");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}

void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    gchar *id;
    menu u;
    GtkWidget *pInfo;
    GtkTreeModel *model=gtk_tree_view_get_model(treeview);
    if(gtk_tree_model_get_iter(model,&iter,path)){
    gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
    strcpy(u.id,id);
    pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce menu?");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_YES:
    gtk_widget_destroy(pInfo);
    supprimer2(u,"menu.txt");
    afficher2(treeview,"menu.txt");
    break;
    case GTK_RESPONSE_NO:
    gtk_widget_destroy(pInfo);
    break;
}   
}
}
void
on_affichera_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *afa, *amal;
afa=lookup_widget(button,"afa");
afa=create_afa();
gtk_widget_show(afa);
treeview=lookup_widget(afa,"treeview6");
afficher3(treeview,"menu.txt");
}


void
on_meilleur_menu_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *b, *pInfo;
char str[1000], ch[1000]="";
strcpy(ch,meilleur_menu("menu.txt"));
b=lookup_widget(button,"meilleur_menu");
sprintf(str,"%s",ch);
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}


void
on_check_id3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo, *mod4;
menu p;
int a=0;
char ch[20], id[50];
FILE *f;
mod1=lookup_widget(button,"entry22");
mod2=lookup_widget(button,"entry21");
mod3=lookup_widget(button,"entry23");
mod4=lookup_widget(button,"combobox6");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("menu.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %f %d %d %d\n",p.id,&(p.type),p.nom,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
    {
        if(strcmp(p.id,id)==0){
            a=1;
            break;
                 }
    }
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2),p.nom);
sprintf(ch,"%.2f",p.dechet);
gtk_entry_set_text(GTK_ENTRY(mod3),ch);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),p.type);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Menu introuvable");
    switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
    {
    case GTK_RESPONSE_OK:
    gtk_widget_destroy(pInfo);
    break;
    }
}
}


void
on_button_moda_clicked                 (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *moda, *amal;
amal=lookup_widget(button,"amal");
moda=lookup_widget(button,"moda");
moda=create_moda();
gtk_widget_show(moda);
}



void
on_affa_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af, *dashboard;
af=lookup_widget(button,"af");
af=create_af();
gtk_widget_show(af);
treeview=lookup_widget(af,"treeview6");
afficher3(treeview,"menu.txt");
}


void
on_button_aja_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *a, *b, *c;
GtkCalendar *ajc;
menu u;
guint day, month, year;
aj1=lookup_widget(button,"entry26");
aj2=lookup_widget(button,"entry24");
aj3=lookup_widget(button,"entry25");
ajc=lookup_widget(button,"calendar1");
a=lookup_widget(button,"radiobutton9");
b=lookup_widget(button,"radiobutton10");
c=lookup_widget(button,"radiobutton11");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(aj1)));
u.type=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(a))?0:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b))?1:2;
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(aj2)));
u.dechet=atof(gtk_entry_get_text(GTK_ENTRY(aj3)));
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
u.d.j=year;
u.d.m=month+1;
u.d.a=day;
ajouter2(u,"menu.txt");
}




void
on_hh_rechercher_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_rupture_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_supp_oui_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_affich_supp_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_supp_valider_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_ajout_prod_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_annuler_ajout_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_affich_ajout_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_fruit_a_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_legume_a_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_viande_a_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_liquides_a_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_ingredients_a_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_annuler_modif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_affich_modif_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_rech_valider_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour_recherche_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_hh_rupture_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_retour_rupture_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}

