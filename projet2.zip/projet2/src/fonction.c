#include "fonction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>


enum
{
	ETYPE,
	ENOM,
	EID,
	EKG,
	EJOUR_AJ,
	EMOIS_AJ,
	EJANNEE_AJ,
	EJOUR_EXP,
	EMOIS_EXP,
	EANNEE_EXP,
        COLUMNS,
};


///////////////////////////////////////////////////////////////////////////////////////////

void ajouter(nourriture n)
{
  //  char id[50];
   // char type[50];
   // char nom[50];
   // date date_exp,date_ajout;
    //char kg[10];
FILE *f;
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d %d %d %d \n",n.type,n.nom,n.id,n.kg,n.date_ajout.jour,n.date_ajout.mois,n.date_ajout.annee,n.date_exp.jour,n.date_exp.mois,n.date_exp.annee);
fclose(f);
}

}



/////////////////////////////////////////////////////////////////////////////////////////


int modifier(nourriture n)
{
FILE*f;
FILE*f1;
char id1[20];
  char type[30];
  char nom[30];
  int jour_aj;
  int mois_aj;
  int annee_aj;
  int jour_exp;
  int mois_exp;
  int annee_exp;
  char kg[10];

f=fopen("utilisateur.txt","r");
f1=fopen("nouveau.txt","a+");

while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",type,nom,id1,kg,&jour_aj,&mois_aj,&annee_aj,&jour_exp,&mois_exp,&annee_exp)!=EOF)
{
if(strcmp(n.id,id1)==0)
{
fprintf(f1,"%s %s %s %s %d %d %d %d %d %d\n",n.type,n.nom,n.id,n.kg,n.date_ajout.jour,n.date_ajout.mois,n.date_ajout.annee,n.date_exp.jour,n.date_exp.mois,n.date_exp.annee);
}
else 
fprintf(f1,"%s %s %s %s %d %d %d %d %d %d\n",type,nom,id1,kg,&jour_aj,&mois_aj,&annee_aj,&jour_exp,&mois_exp,&annee_exp);
}

fclose(f);
fclose(f1);

remove("utilisateur.txt");
rename("nouveau.txt","utilisateur.txt");
}



/////////////////////////////////////////////////////////////////////////////////////////////////


int supprimer(char id[])
{
  nourriture n;
FILE *f;
FILE *g;
f=fopen("utilisateur.txt","r");
g=fopen("temp.txt","a+");

if (f==NULL || g==NULL )
	return;
else
{
while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",n.nom,n.type,n.id,&n.kg,&n.date_ajout.jour,&n.date_ajout.mois,&n.date_ajout.annee,&n.date_exp.jour,&n.date_exp.mois,&n.date_exp.annee)!=EOF)
{
if( strcmp(n.id,id)!=0)
{
fprintf(g,"%s %s %s %s %d %d %d %d %d %d\n",n.nom,n.type,n.id,n.kg,n.date_ajout.jour,n.date_ajout.mois,n.date_ajout.annee,n.date_exp.jour,n.date_exp.mois,n.date_exp.annee);
}
}
}
fclose(f);
fclose(g);
remove("utilisateur.txt");
rename("temp.txt","utilisateur.txt");
return 1;
}



////////////////////////////////////////////////////////////////////////////////////////////


void rechercher(GtkWidget *liste,char id1[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char id[20];
  char type[30];
  char nom[30];
  int jour_aj;
  int mois_aj;
  int annee_aj;
  int jour_exp;
  int mois_exp;
  int annee_exp;
  char kg[10];
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" kg",renderer,"text",EKG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//////////////
renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_aj",renderer,"text",EJOUR_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_aj",renderer,"text",EMOIS_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_aj",renderer,"text",EJANNEE_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_exp",renderer,"text",EJOUR_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_exp",renderer,"text",EMOIS_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_exp",renderer,"text",EANNEE_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
/////////////////////////////

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilisateur.txt","a+");
   while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",type,nom,id,kg,&jour_aj,&mois_aj,&annee_aj,&jour_exp,&mois_exp,&annee_exp)!= EOF)
{
 if(strcmp(id,id1)==0)                  
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,ETYPE,type,ENOM,nom,EID,id,EKG,kg,EJOUR_AJ,jour_aj,EMOIS_AJ,mois_aj,EJANNEE_AJ,annee_aj,EJOUR_EXP,jour_exp,EMOIS_EXP,mois_exp,EANNEE_EXP,annee_exp,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}



///////////////////////////////////////////////////////////////////////////////////////////

void  afficher(GtkWidget *liste){
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char id[20];
  char type[30];
  char nom[30];
  int jour_aj;
  int mois_aj;
  int annee_aj;
  int jour_exp;
  int mois_exp;
  int annee_exp;
  char kg[10];
  store=NULL ;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" kg",renderer,"text",EKG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//////////////
renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_aj",renderer,"text",EJOUR_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_aj",renderer,"text",EMOIS_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_aj",renderer,"text",EJANNEE_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_exp",renderer,"text",EJOUR_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_exp",renderer,"text",EMOIS_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_exp",renderer,"text",EANNEE_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
/////////////////////////////

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilisateur.txt","a+");
   while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",type,nom,id,kg,&jour_aj,&mois_aj,&annee_aj,&jour_exp,&mois_exp,&annee_exp)!= EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ETYPE,type,ENOM,nom,EID,id,EKG,kg,EJOUR_AJ,jour_aj,EMOIS_AJ,mois_aj,EJANNEE_AJ,annee_aj,EJOUR_EXP,jour_exp,EMOIS_EXP,mois_exp,EANNEE_EXP,annee_exp,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}



////////////////////////////////////////////////////////////////////////////////////////


void rupture(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
  char id[20];
  char type[30];
  char nom[30];
  int jour_aj;
  int mois_aj;
  int annee_aj;
  int jour_exp;
  int mois_exp;
  int annee_exp;
  char kg[10];
  float kgf;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL){
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" kg",renderer,"text",EKG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

//////////////
renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_aj",renderer,"text",EJOUR_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_aj",renderer,"text",EMOIS_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_aj",renderer,"text",EJANNEE_AJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" jour_exp",renderer,"text",EJOUR_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" mois_exp",renderer,"text",EMOIS_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer =gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" annee_exp",renderer,"text",EANNEE_EXP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
/////////////////////////////

}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilisateur.txt","a+");
   while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",type,nom,id,kg,&jour_aj,&mois_aj,&annee_aj,&jour_exp,&mois_exp,&annee_exp)!= EOF)
{
 kgf=atof(kg);
 if(kgf<5)                  
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,ETYPE,type,ENOM,nom,EID,id,EKG,kg,EJOUR_AJ,jour_aj,EMOIS_AJ,mois_aj,EJANNEE_AJ,annee_aj,EJOUR_EXP,jour_exp,EMOIS_EXP,mois_exp,EANNEE_EXP,annee_exp,-1);
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}

/////////////////////////////////////////////////////////////////////////////////////////

int test_produit(char *id1[])
{
FILE *f=NULL;
    nourriture n;

    f = fopen("utilisateur.txt","r");
    while (fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",n.nom,n.type,n.id,&n.kg,&n.date_ajout.jour,&n.date_ajout.mois,&n.date_ajout.annee,&n.date_exp.jour,&n.date_exp.mois,&n.date_exp.annee)!=EOF)
	{
            if (strcmp(n.id,id1)==0)
		return 1;   //id existe deja 
	}	
fclose(f);
return 0;
}
