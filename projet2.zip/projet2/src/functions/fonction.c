#include "fonction.h"
#include <stdio.h>
#include <stdlib.h>

void ajouter(char fich[],nourriture n){
    FILE *f=NULL;

    char id[50];
    char type[50];
    char nom[50];
    date date_exp;
    date date_ajout;
    float kg;

    f = fopen(fich,"a+");
    if (f!=NULL){

        printf("Give the type of the product\n");
        scanf("%s",n.type);

        printf("Give the name of the product\n");
        scanf("%s",n.nom);

        printf("Give the ID of the product\n");
        scanf("%s",n.id);

        printf("Give the quantity to add\n");
        scanf("%f",&n.kg);

        printf("Give the  date \n");
        scanf("%d%d%d",&n.date_ajout.jour,&n.date_ajout.mois,&n.date_ajout.annee);

        printf("Give the limit date\n");
        scanf("%d%d%d",&n.date_exp.jour,&n.date_exp.mois,&n.date_exp.annee);

        fprintf(f,"%s %s %s %f %d %d %d %d %d %d \n",n.nom,n.type,n.id,n.kg,n.date_ajout.jour,n.date_ajout.mois,n.date_ajout.annee,n.date_exp.jour,n.date_exp.mois,n.date_exp.annee);
    }
    fclose(f);

}






void modifier(char fich[], char id1[]){
    FILE *f=NULL;
    FILE *t = NULL;
    char id[50];
    char type[50];
    char nom[50];
    date date_exp,date_ajout;
    float kg;


    f = fopen(fich,"r");
    t = fopen("temp.txt" , "a+");
    char a;
    if (f!=NULL)
    {
    while (fscanf(f,"%s %s %s %f %d %d %d %d %d %d\n",nom,type,id,&kg,&date_ajout.jour,&date_ajout.mois,&date_ajout.annee,&date_exp.jour,&date_exp.mois,&date_exp.annee)!=EOF){
            if (strcmp(id,id1)==0){
            do {

                printf("1.changer le type\n");
                printf("2.changer le nom\n");
                printf("3.changer la quantite \n");
                printf("4.changer le jour d'expiration\n");
                printf("5.changer le mois d'expiration\n");
                printf("6.changer l'année d'expiration \n");
                scanf(" %c",&a);
            }while (a!='1' && a!='2' && a!='3' && a!='4' && a!='5' && a!='6' && a!='7' && a!='8' && a!='9') ;
                switch (a){
                case '1':
                    printf("donner le type\n");
                    scanf("%s",nom);

                    break;
                case '2':
                    printf("donner le nom\n");
                    scanf("%s",nom);

                    break;
                case '3':
                    printf("donner la quantite \n");
                    scanf(" %c",&kg);

                    break;
                case '4':

                    printf("donner le jour d'expiration\n");
                    scanf("%d",&date_exp.jour);
                    break;
                case '5':

                    printf("donner le mois d'expiration \n");
                    scanf("%d",&date_exp.mois);
                    break;
                case '6':

                    printf("donner l'année d'expiration\n");
                    scanf("%d",&date_exp.annee);
                    break;
                }
            }

            fprintf(t,"%s %s %s %f %d %d %d %d %d %d \n",nom,type,id,kg,date_ajout.jour,date_ajout.mois,date_ajout.annee,date_exp.jour,date_exp.mois,date_exp.annee);

        }
        fclose(f);
        remove(fich);
        fclose(t);
        rename("temp.txt",fich);

    }

}






void supprimer(char fich[], char id1[]){
    FILE *f=NULL;
    FILE *t = NULL;

    char id[50];
    char type[50];
    char nom[50];
    date date_exp,date_ajout;
    float kg;

    f = fopen(fich,"r");
    t = fopen("temp.txt" , "a+");
    char a;
    if (f!=NULL)
    {
    while (fscanf(f,"%s %s %s %f %d %d %d %d %d %d\n",nom,type,id,&kg,&date_ajout.jour,&date_ajout.mois,&date_ajout.annee,&date_exp.jour,&date_exp.mois,&date_exp.annee)!=EOF){
            if (strcmp(id,id1)!=0){
                fprintf(t,"%s %s %s %f %d %d %d %d %d %d \n",nom,type,id,kg,date_ajout.jour,date_ajout.mois,date_ajout.annee,date_exp.jour,date_exp.mois,date_exp.annee);
            }
        }
        fclose(f);
        remove(fich);
        fclose(t);
        rename("temp.txt",fich);

    }

}






void rechercher(char fich[], char id1[]){
    FILE *f=NULL;

    char id[50];
    char type[50];
    char nom[50];
    date date_exp,date_ajout;
    float kg;

    f = fopen(fich,"r");
    if (f!=NULL)
    {
    while (fscanf(f,"%s %s %s %f %d %d %d %d %d %d\n",nom,type,id,&kg,&date_ajout.jour,&date_ajout.mois,&date_ajout.annee,&date_exp.jour,&date_exp.mois,&date_exp.annee)!=EOF){
            if (strcmp(id1,id)==0){
                    printf("ID:%s TYPE:%s NOM:%s QUANTITE:%f JOUR D'EXPIRATION:%d MOIS D'EXPIRATION:%d ANNEE D'EXPIARTION:%d \n",id,type,nom,kg,date_exp.jour,date_exp.mois,date_exp.annee);
            }
        }
        fclose(f);
    }
}






void afficher(char fich[]){
     FILE *f=NULL;

    char id[50];
    char type[50];
    char nom[50];
    date date_exp,date_ajout;
    float kg;

    f = fopen(fich,"r");
    if (f!=NULL)
    {
    while (fscanf(f,"%s %s %s %f %d %d %d %d %d %d\n",nom,type,id,&kg,&date_ajout.jour,&date_ajout.mois,&date_ajout.annee,&date_exp.jour,&date_exp.mois,&date_exp.annee)!=EOF){
                    printf("%s %s %s %f %d %d %d %d %d %d \n",nom,type,id,kg,date_ajout.jour,date_ajout.mois,date_ajout.annee,date_exp.jour,date_exp.mois,date_exp.annee);

        }
        fclose(f);
    }
}






void rupture(char fich[]){
    FILE* f;

    nourriture D;
    float kilo;

    f=fopen(fich,"r");
    if(f!=NULL)
        {
        while(fscanf(f,"%s %s %s %f %d %d %d %d %d %d\n",D.nom,D.type,D.id,&D.kg,&D.date_ajout.jour,&D.date_ajout.mois,&D.date_ajout.annee,&D.date_exp.jour,&D.date_exp.mois,&D.date_exp.annee)!=EOF)
            {
            if(D.kg<2)
                {
                printf("NOM :%s\n",D.nom);
                }
            }
        }
    fclose(f);
}
