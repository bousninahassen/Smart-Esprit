

typedef struct
{
int jour;
int mois ;
int annee;
}date;


typedef struct
{
char id[50];
char type[50];
char nom[50];
date date_exp;
date date_ajout;
float kg;
}nourriture;

void ajouter(char fich[],nourriture n);
void modifier(char fich[], char id[]);
void supprimer(char fich[],char id[]);
void rechercher(char fich[], char id[]);
void afficher(char fich[]);
void rupture(char fich[]);


